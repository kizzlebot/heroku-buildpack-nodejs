//
//  main.m
//  Randomify
//
//  Created by Joachim Bengtsson on 2010-03-30.
//  Copyright 2010 Spotify. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
